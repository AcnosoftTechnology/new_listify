@if ($text = listing_distance_text($listing))
    <span class="listing-distance-tag" title="{{ get_phrase('Distance from your location') }}">
        <svg class="listing-distance-tag__icon" width="13" height="13" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M17.1833 7.04166C16.3083 3.19166 12.95 1.45833 9.99996 1.45833C7.04996 1.45833 3.68329 3.18333 2.80829 7.03333C1.83329 11.3333 4.46662 14.975 6.84996 17.2667C7.73329 18.1167 8.86662 18.5417 9.99996 18.5417C11.1333 18.5417 12.2666 18.1167 13.1416 17.2667C15.525 14.975 18.1583 11.3417 17.1833 7.04166ZM9.99996 11.2167C8.54996 11.2167 7.37496 10.0417 7.37496 8.59166C7.37496 7.14166 8.54996 5.96666 9.99996 5.96666C11.45 5.96666 12.625 7.14166 12.625 8.59166C12.625 10.0417 11.45 11.2167 9.99996 11.2167Z" fill="currentColor"/>
        </svg>
        <span class="listing-distance-tag__text">{{ $text }}</span>
    </span>
@endif
